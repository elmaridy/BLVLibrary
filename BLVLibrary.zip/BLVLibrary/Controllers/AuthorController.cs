﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLVLibrary.Models;
using BLVLibrary.Filters;
using System.Net;
using System.Data.Entity;

namespace BLVLibrary.Controllers
{
    [UserAuthorization]
    public class AuthorController : Controller
    {
        [AdminAuthorization]
        // GET: Author
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [AdminAuthorization]
        public ActionResult Create([Bind(Exclude = "AuthorImage")]Author author)
        {
            var file = Request.Files[0];
            if (file != null && file.ContentLength > 0)
            {
                var content = new byte[file.ContentLength];
                file.InputStream.Read(content, 0, file.ContentLength);
                author.AuthorImage = content;
            }
            LibraryEntities1 context = new LibraryEntities1();
            context.Authors.Add(author);
            context.SaveChanges();
            return View();
        }
        [HttpGet]
        public ActionResult List(int? id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            IQueryable<Author> sources = null;
            if (id != null)
            {
                sources = context.Authors.Where(s => s.AuthorID == id).OrderBy(s => s.AuthorName);
            }
            else
            {
                sources = context.Authors.OrderBy(s => s.AuthorName);
            }
            return View(sources.ToList());
        }
        public FileContentResult getImg(int id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            byte[] byteArray = context.Authors.Find(id).AuthorImage;
            return byteArray != null
                ? new FileContentResult(byteArray, "image/jpeg")
                : null;
        }
        [AdminAuthorization]
        public ActionResult Edit(int? id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Author author = context.Authors.Find(id);
            if (author == null)
            {
                return HttpNotFound();
            }
            return View(author);
        }
        [HttpPost]
        [AdminAuthorization]
        public ActionResult Edit([Bind(Exclude = "AuthorImage")] Author author)
        {
            LibraryEntities1 context = new LibraryEntities1();
            var baseauthor = context.Authors.Where(s => s.AuthorID == author.AuthorID).FirstOrDefault();
            baseauthor.AuthorName = author.AuthorName;
            var file = Request.Files[0];
            if (file != null && file.ContentLength > 0)
            {
                var content = new byte[file.ContentLength];
                file.InputStream.Read(content, 0, file.ContentLength);
                baseauthor.AuthorImage = content;
            }
            if (ModelState.IsValid)
            {
                context.Entry(baseauthor).State = EntityState.Modified;
                context.SaveChanges();
                return RedirectToAction("List");
            }
            return View(author);
        }
        [AdminAuthorization]
        public ActionResult Delete(int? id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Author author = context.Authors.Find(id);
            if (author == null)
            {
                return HttpNotFound();
            }
            else
            {
                context.Authors.Remove(author);
                context.SaveChanges();
            }
            return RedirectToAction("List");
        }
    }
}