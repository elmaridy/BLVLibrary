﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLVLibrary.Models;
using BLVLibrary.Filters;
using System.Security.Cryptography;
using System.Text;
using System.Data.Entity;
using System.Net;

namespace BLVLibrary.Controllers
{
    public class UserController : Controller
    {
        // Create
        public ActionResult Register()
        {
            if (Request.Cookies["UEmail"] != null && Request.Cookies["UPassword"] != null)
            {
                LibraryEntities1 context = new LibraryEntities1();
                string password = Request.Cookies["UPassword"].Value;
                string email = Request.Cookies["UEmail"].Value;
                var result = context.Users.Where(u => u.Email == email && u.Password == password).SingleOrDefault();
                if (result != null)
                {
                    Session["UserID"] = result.UserID;
                    Session["IsAdmin"] = result.IsAdmin;
                    return RedirectToAction("Detail", new { id = result.UserID });
                }
                else
                {
                    //Remove Cookies
                    var ecookie = new HttpCookie("UEmail");
                    ecookie.Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(ecookie);
                    var passcookie = new HttpCookie("UPassword");
                    passcookie.Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(passcookie);
                }
            }
            return View();
        }
        //Insert
        [HttpPost]
        public ActionResult Register([Bind(Exclude = "UserImage,UserID")]User user )
        {
            user.Password = Encryptor.Encode(user.Password);
            var file = Request.Files[0];
            if (file != null && file.ContentLength > 0)
            {
                var content = new byte[file.ContentLength];
                file.InputStream.Read(content, 0, file.ContentLength);
                user.UserImage = content;
            }
            user.IsAdmin = false;
            LibraryEntities1 context = new LibraryEntities1();
            context.Users.Add(user);
            context.SaveChanges();
            Session["UserID"] = user.UserID;
            Session["IsAdmin"] = false;
            return RedirectToAction("Detail",new { id = user.UserID});
        }
        //Login
        public ActionResult Login()
        {
            if (Request.Cookies["UEmail"] != null && Request.Cookies["UPassword"] != null)
            {
                string password = Request.Cookies["UPassword"].Value;
                string email = Request.Cookies["UEmail"].Value.ToString();
                LibraryEntities1 context = new LibraryEntities1();
                var result = context.Users.Where(u => u.Email == email && u.Password == password).SingleOrDefault();
                if (result != null)
                {
                    Session["UserID"] = result.UserID;
                    Session["IsAdmin"] = result.IsAdmin;
                    return RedirectToAction("Detail", new { id = result.UserID });
                }
                else
                {
                    //Remove Cookies
                    var ecookie = new HttpCookie("UEmail");
                    ecookie.Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(ecookie);
                    var passcookie = new HttpCookie("UPassword");
                    passcookie.Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(passcookie);
                }
            }
            return View("Login");
        }
        //Login
        [HttpPost]
        public ActionResult Login(string email, string password, bool rememberme)
        {
            password = Encryptor.Encode(password);
            LibraryEntities1 context = new LibraryEntities1();
            var result = context.Users.Where(u => u.Email == email && u.Password == password).SingleOrDefault();
            if (result != null)
            {
                Session["UserID"] = result.UserID;
                Session["IsAdmin"] = result.IsAdmin;
                if(rememberme == true)
                {
                    HttpCookie emailCookie = new HttpCookie("UEmail", email);
                    HttpCookie passCookie = new HttpCookie("UPassword", password);
                    Response.Cookies.Add(emailCookie);
                    Response.Cookies.Add(passCookie);
                }
                return RedirectToAction("Detail", new { id = result.UserID});
            }
            else
            {
                return View("Login");
            }
        }
        public ActionResult Logout()
        {
            if (Request.Cookies["UEmail"] != null && Request.Cookies["UPassword"] != null)
            {
                //Remove Cookies
                var ecookie = new HttpCookie("UEmail");
                ecookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(ecookie);
                var passcookie = new HttpCookie("UPassword");
                passcookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(passcookie);
            }
            Session["UserID"] = null;
            Session["IsAdmin"] = null;
            return RedirectToAction("Login");
        }
        [UserAuthorization]
        public ActionResult Detail(int? id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = context.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            var Downloads = context.User_Source.Include(s => s.User).Where(s => s.UserID == id).OrderBy(s => s.Date);
            ViewBag.Downloads = Downloads;
            return View(user);
        }
        [UserAuthorization]
        public FileContentResult getImg(int id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            byte[] byteArray = context.Users.Find(id).UserImage;
            return byteArray != null
                ? new FileContentResult(byteArray, "image/jpeg")
                : null;
        }
        [UserAuthorization]
        [AdminAuthorization]
        public ActionResult List()
        {
            LibraryEntities1 context = new LibraryEntities1();
            var users = context.Users.OrderBy(s => s.Name);
            return View(users.ToList());
        }
        [UserAuthorization]
        [AdminAuthorization]
        public ActionResult SetAsAdmin(int id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            User user = context.Users.Find(id);
            context.Entry(user).State = EntityState.Modified;
            context.SaveChanges();
            return RedirectToAction("List");
        }
        // GET: Users/Edit/5
        [UserAuthorization]
        public ActionResult Edit(int? id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if (id != (int)Session["UserID"])
            {
                return View("~/Shared/Error.cshtml");
            }
            User user = context.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }
        [HttpPost]
        [UserAuthorization]
        public ActionResult Edit([Bind(Exclude = "UserImage")] User user)
        {
            if (user.UserID != (int)Session["UserID"])
            {
                return View("~/Shared/Error.cshtml");
            }
            LibraryEntities1 context = new LibraryEntities1();
            var baseuser = context.Users.Where(s => s.UserID == user.UserID).FirstOrDefault();
            if (user.Password != null)
            {
                baseuser.Password = Encryptor.Encode(user.Password);
            }
            baseuser.Gender = user.Gender;
            baseuser.DOB = user.DOB;
            var file = Request.Files[0];
            if (file != null && file.ContentLength > 0)
            {
                var content = new byte[file.ContentLength];
                file.InputStream.Read(content, 0, file.ContentLength);
                baseuser.UserImage = content;
            }
            if (ModelState.IsValid)
            {
                context.Entry(baseuser).State = EntityState.Modified;
                context.SaveChanges();
                return RedirectToAction("Detail",new { id = Session["UserID"]});
            }
            return View(user);
        }
    }
    
}