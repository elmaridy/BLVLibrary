﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Web;
using System.Web.Mvc;
using System.Net;
using BLVLibrary.Models;
using BLVLibrary.Filters;

namespace BLVLibrary.Controllers
{
    [UserAuthorization]
    public class SourceController : Controller
    {
        // GET: Source
        [HttpGet]
        public ActionResult List(int? id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            IQueryable<Source> sources = null;
            if (id != null)
            {
                sources = context.Sources.Include(s => s.Author).OrderBy(s => s.SourceName).Where(s => s.Author.AuthorID == id);
            }
            else
            {
                sources = context.Sources.Include(s => s.Author).Include(s => s.User).OrderBy(s => s.SourceName);
            }
            return View(sources.ToList());
        }
        //Convert bytes to image
        public FileContentResult getImg(int id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            byte[] byteArray = context.Sources.Find(id).SourcePoster;
            return byteArray != null
                ? new FileContentResult(byteArray, "image/jpeg")
                : null;
        }
        public ActionResult Download(int id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            var type = context.Sources.Find(id).SourceType;
            var Source = context.Sources.Where(s => s.SourceID == id).SingleOrDefault();
            string file = Source.SourceFile;
            Source.NumberOfDownloads++;
            User_Source newDownload = new User_Source();
            newDownload.SourceName  = Source.SourceName;
            newDownload.UserID = (int)Session["UserID"];
            newDownload.Date = DateTime.Today;
            context.User_Source.Add(newDownload);
            context.SaveChanges();
            if (Source.SourceType == "Text")
            {
                string contentType = "application/pdf";
                return File("~/SourcesFiles/" + file, contentType, file);
            }
            else if (Source.SourceType == "Sound")
            {
                string contentType = "audio/mpeg";
                return File("~/SourcesFiles/" + file, contentType, file);
            }
            else if (Source.SourceType == "Video")
            {
                string contentType = "video/mp4";
                return File("~/SourcesFiles/" + file, contentType, file);
            }
            else return null;
        }
        [AdminAuthorization]
        public ActionResult Create(int? id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            ViewBag.AuthorID_ArtistID = new SelectList(context.Authors, "AuthorID", "AuthorName");
            ViewBag.UploaderID = Session["UserID"];
            if (id != null)
            {
                ViewBag.Error = id;
            }
            return View("Create");
        }
        [HttpPost]
        [AdminAuthorization]
        public ActionResult Create([Bind(Exclude = "SourcePoster,SourceFile")]Source source)
        {
            source.UploaderID = int.Parse(Session["UserID"].ToString());
            source.AuthorID_ArtistID = int.Parse(Request.Form["AuthorID/ArtistID"].ToString());
            source.NumberOfDownloads = 0;
            var file = Request.Files[0];
            if (file != null && file.ContentLength > 0)
            {
                var content = new byte[file.ContentLength];
                file.InputStream.Read(content, 0, file.ContentLength);
                source.SourcePoster = content;
            }
            var file2 = Request.Files[1];
            if (file2 != null && file.ContentLength > 0)
            {
                string extension = System.IO.Path.GetExtension(file2.FileName);
                if (extension != ".mp3" && extension != ".mp4" && extension != ".pdf")
                {
                    return RedirectToAction("Create", new { id = 1 });
                }
                if ((extension == ".mp3" && source.SourceType != "Sound") || (extension == ".mp4" && source.SourceType != "Video") || (extension == ".pdf" && source.SourceType != "Text"))
                {
                    return RedirectToAction("Create", new { id = 1 });
                }
                file2.SaveAs(Server.MapPath("~/SourcesFiles/" + source.SourceName + extension));
                source.SourceFile = source.SourceName + extension;
            }
            LibraryEntities1 context = new LibraryEntities1();
            context.Sources.Add(source);
            context.SaveChanges();
            return RedirectToAction("List");
        }
        [AdminAuthorization]
        public ActionResult Edit(int? id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Source source = context.Sources.Find(id);
            if (source == null)
            {
                return HttpNotFound();
            }
            return View(source);
        }
        [HttpPost]
        [AdminAuthorization]
        public ActionResult Edit([Bind(Exclude = "SourcePoster")] Source source)
        {
            LibraryEntities1 context = new LibraryEntities1();
            var basesource = context.Sources.Where(s => s.SourceID == source.SourceID).FirstOrDefault();
            basesource.SourceName = source.SourceName;
            var file = Request.Files[0];
            if (file != null && file.ContentLength > 0)
            {
                var content = new byte[file.ContentLength];
                file.InputStream.Read(content, 0, file.ContentLength);
                basesource.SourcePoster = content;
            }
            if (ModelState.IsValid)
            {
                context.Entry(basesource).State = EntityState.Modified;
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(source);
        }
        [AdminAuthorization]
        public ActionResult Delete(int? id)
        {
            LibraryEntities1 context = new LibraryEntities1();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Source source = context.Sources.Find(id);
            if (source == null)
            {
                return HttpNotFound();
            }
            else
            {
                
                string fullPath = Request.MapPath("~/SourcesFiles/" + source.SourceFile);
                if ((System.IO.File.Exists(fullPath)))
                {
                    System.IO.File.Delete(fullPath);
                }
                context.Sources.Remove(source);
                context.SaveChanges();
            }
            return RedirectToAction("List");

        }
    }
}